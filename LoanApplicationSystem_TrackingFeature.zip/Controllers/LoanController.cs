using System;
using System.Linq;
using System.Web.Mvc;
using LoanApplicationSystem.Models;

namespace LoanApplicationSystem.Controllers
{
    public class LoanController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Track(int id)
        {
            var app = db.LoanApplications.Find(id);
            if (app == null)
            {
                return HttpNotFound();
            }

            var viewModel = new LoanTrackingViewModel
            {
                ApplicationId = app.ApplicationId,
                CompanyName = app.CompanyName,
                LoanType = app.LoanType,
                LoanAmount = app.LoanAmount,
                Status = app.Status,
                SubmissionDate = app.SubmissionDate
            };

            return View(viewModel);
        }
    }
}